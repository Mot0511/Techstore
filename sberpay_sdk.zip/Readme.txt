Описание логики перебора deeplkink (можно использовать для desktop) - WebScenario.docx
Документация по методам имплементации - SberPay_SDK_Doc.pdf
Гайдлайны - SberPay_SDK_guideline.zip
Android SDK - sberpaysdk-release-1.3.aar
Исходные коды IOS SDK - DeploySDK.zip
IOS SDK - SberPaySDK_iOS_1.2.zip
IOS SDK bitcode - SberPaySDK_iOS_1.2_bitcode.zip


